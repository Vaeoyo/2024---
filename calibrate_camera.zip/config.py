L1 = 150
L2 = 140
CornerLength = 325
JointBase1 = 45
JointBase2 = 135
joint_pin_1 = 17
joint_pin_2 = 18
joint_pin_3 = 27
electromagnet_pin = 22
input_pin = 23
led_pin = 24
camera_index = 3
center_offset = (6, -10)
grid_offset = [
    (5, -7),
    (4, -7),
    (5, -7),
    (5, -7),
    (5, -7),
    (5, -7),
    (5, -7),
    (5, -7),
    (5, -7),
]
